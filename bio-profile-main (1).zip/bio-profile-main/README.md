# bio-profile
This website project is my first for SHECODES PLUS. A program designed to help women learn to build websites and applications using HTML/CSS platform and a host of other platforms too.
